#dht11 with led

import Adafruit_DHT
import time
import RPi.GPIO as GP
import RPi.GPIO as GP1

GP.setmode(GP.BCM)
GP.setup(27,GP.OUT)
GP1.setmode(GP1.BCM)
GP1.setup(22,GP1.OUT)

sensor=Adafruit_DHT.DHT11
gpio=16
humidity, temperature = Adafruit_DHT.read_retry(sensor, gpio)
i=0
while True:
    if humidity is not None and temperature is not None:
      print('Temp={0:0.1f}*C  Humidity={1:0.1f}%'.format(temperature, humidity))
    else:
      print('Failed to get reading. Try again!')
    if temperature >= 20:
        GP.output(27,GP.HIGH)
        time.sleep(1)
        GP.output(27,GP.LOW)
        time.sleep(1)
    if humidity >= 40:
        GP1.output(22,GP1.HIGH)
        time.sleep(1)
        GP1.output(22,GP1.LOW)
        time.sleep(1)
    time.sleep(2.00)
