import RPi.GPIO as GP
import time
GP.setmode(GP.BCM)
GP.setup(24,GP.OUT)
p=GP.PWM(24,50)
p.start(0)
while True:
    for i in range (50):
        p.ChangeDutyCycle(i)
        time.sleep(0.08)
    for i in range (50):
        p.ChangeDutyCycle(50-i)
        time.sleep(0.08)
p.stop()
