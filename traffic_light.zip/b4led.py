import RPi.GPIO as GP
import time
GP.setmode(GP.BCM)
GP.setup(24,GP.OUT)

import RPi.GPIO as GP1
GP1.setmode(GP1.BCM)
GP1.setup(2,GP1.OUT)

while True:
    GP.output(24,GP.HIGH)
    time.sleep(1)
    GP.output(24,GP.LOW)
    time.sleep(1)

    GP1.output(2,GP1.HIGH)
    time.sleep(1)
    GP1.output(2,GP1.LOW)
    time.sleep(1)


    
