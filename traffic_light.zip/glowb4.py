import RPi.GPIO as GP
import time
GP.setmode(GP.BCM)
GP.setup(24,GP.OUT)

while True:
    GP.output(24,GP.HIGH)
    time.sleep(1)
    GP.output(24,GP.LOW)
    time.sleep(1)
