import RPi.GPIO as traffic
import time
traffic.setmode(traffic.BCM)
traffic.setup(15,traffic.OUT) #green
traffic.setup(18,traffic.OUT) #yellow
traffic.setup(24,traffic.OUT) #red
traffic.setup(20,traffic.OUT)  #trigger
traffic.setup(21,traffic.IN)  #echo
traffic.output(20,traffic.LOW)
print("Waiting...")
time.sleep(2)
traffic.output(20,traffic.HIGH)
time.sleep(0.0001)
traffic.output(20,traffic.LOW)
while traffic.input(21)==0 :
    start=time.time()
while traffic.input(21)==1 :
    end=time.time()
dur=end-start
distance=round(dur*17150,2)
print("Distance:",distance,"cm")
if(distance<=15):
    print("STOP")
    traffic.output(24,traffic.HIGH)
    time.sleep(5)
    traffic.output(24,traffic.LOW)
elif(15<=distance<=20):
    print("SLOW DOWN")
    traffic.output(18,traffic.HIGH)
    time.sleep(5)
    traffic.output(18,traffic.LOW)
elif(distance>20):
    print("GO")
    traffic.output(15,traffic.HIGH)
    time.sleep(7)
    traffic.output(15,traffic.LOW)
traffic.cleanup()
