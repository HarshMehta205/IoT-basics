#command to install paho mqtt broker
#sudo pip3 install paho-mqtt
import paho.mqtt.client as paho    #importing paho package
import Adafruit_DHT as dht
import time
import RPi.GPIO as GP

broker="broker.hivemq.com" #online broker

GP.setmode(GP.BCM)

#only for printing purpose
def on_connect(client,userdata,flags,rc):
    print("Publisher connected with result code"+str(rc))
    time.sleep(2)

#fn for dht11 code
def dht_fn():
    humidity, temperature = dht.read_retry(11,16)   #11->dht11 16->gpio pin 
    return humidity, temperature  #returning humidity & temperature

client = paho.Client("Client -002")  #creating instance of publisher on client side
print("Connecting to the broker",broker)
client.connect(broker)  #cmd to connect client to the broker
client.on_connect=on_connect

client.loop_start()  #use loop_start or while loop
try:
    while True : #sensing data in while loop
        #h,t=dht_fn()
        #print(h,t)
        print("publishing....")
        client.publish("mit_news", "HELLO WORLD")  #publisher will pass msg 't' for topic 'mitnews' to the client
        time.sleep(2)
except KeyboardInterrupt :
    client.loop_stop()  #to stop & disconnect
    client.disconnect
