import RPi.GPIO as GP
import time
GP.setmode(GP.BCM)
GP.setup(2,GP.IN)
GP.setup(4,GP.OUT)

GP.output(4,GP.LOW)

while True:
    if GP.input(2)==0:
        GP.output(4,GP.HIGH)
    GP.output(4,GP.LOW)
    
