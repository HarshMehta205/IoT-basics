import RPi.GPIO as GP

GP.setmode(GP.BCM)
GPIO_x=27
GPIO_y=17
GP.setup(GPIO_x,GP.OUT)
GP.setup(GPIO_y,GP.OUT)

print"MENU"
print" 1)Clockwise motion \n 2)Anticlockwise motion \n 3)Stop \n 4)EXIT \n"

while True:
    z=input("Enter your choice : ")
    print"Your choice is : ",z
    if z==1:
       GP.output(GPIO_x,GP.HIGH)
       GP.output(GPIO_y,GP.LOW)
       
    elif z==2:
       GP.output(GPIO_x,GP.LOW)
       GP.output(GPIO_y,GP.HIGH)
       
    elif z==3:  
       GP.output(GPIO_x,GP.LOW)
       GP.output(GPIO_y,GP.LOW)
       
    elif z==4:
        exit()
        
    else:
        print"Wrong input"

   

    
   

   