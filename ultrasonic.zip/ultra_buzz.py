#ultrasonic with buzzer

import RPi.GPIO as GP
import time

GP.setmode(GP.BCM)

trig=20
echo=21
buzz=2

GP.setup(trig,GP.OUT)
GP.setup(echo,GP.IN)
GP.setup(buzz,GP.OUT)

while True:
    GP.output(buzz,GP.LOW)
    GP.output(trig,GP.LOW)
    time.sleep(0.01)
    GP.output(trig,GP.HIGH)
    time.sleep(0.01)
    print"trigger generated"
    GP.output(trig,GP.LOW)
    start_time=time.time()
    stop_time=time.time()
    while GP.input(echo)== 0:
        start_time=time.time()
    while GP.input(echo)==1:
        stop_time=time.time()
    total_time=(stop_time-start_time)/2
    distance=total_time*17000
    print (distance)
    if distance > 10:
        GP.output(buzz,GP.HIGH)
    time.sleep(1)
